(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))t(e);new MutationObserver(e=>{for(const c of e)if(c.type==="childList")for(const r of c.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&t(r)}).observe(document,{childList:!0,subtree:!0});function n(e){const c={};return e.integrity&&(c.integrity=e.integrity),e.referrerPolicy&&(c.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?c.credentials="include":e.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function t(e){if(e.ep)return;e.ep=!0;const c=n(e);fetch(e.href,c)}})();const s=document.querySelector("#app");async function i(o){return chrome.runtime.sendMessage(o).catch(a=>({error:a instanceof Error?a.message:"Request failed"}))}function f(o){if(!o)return!1;try{const n=new URL(o).hostname.toLowerCase();return n.endsWith("facebook.com")||n.endsWith("meta.com")}catch{return!1}}async function g(o,a){a.disabled=!0,a.textContent="Scanning Meta Tab...",o.innerHTML='<div class="feedback-card feedback-card--info">Scanning active tab for Meta payment dialog & UPI QR...</div>';try{const[n]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(n!=null&&n.id)||!f(n.url)){o.innerHTML='<div class="feedback-card feedback-card--warn"><div class="feedback-title">Meta Tab Not Found</div>Please switch to your Meta Ads Manager or Billing tab (e.g. facebook.com / adsmanager.facebook.com) and try again.</div>',a.disabled=!1,a.textContent="🔍 Detect QR on Current Tab";return}let t=await chrome.tabs.sendMessage(n.id,{type:"ADS_CONTROL_SCAN"}).catch(()=>null);t||(await chrome.scripting.executeScript({target:{tabId:n.id},files:["content.js"]}).catch(()=>null),t=await chrome.tabs.sendMessage(n.id,{type:"ADS_CONTROL_SCAN"}).catch(()=>null)),t!=null&&t.visible?o.innerHTML=`
        <div class="feedback-card feedback-card--success">
          <div class="feedback-title">✅ Payment QR Detected</div>
          <div><strong>Account:</strong> ${t.account} ${t.accountName?`(${t.accountName})`:""}</div>
          <div><strong>Amount:</strong> ${t.amount}</div>
          <div><strong>QR State:</strong> ${t.qrVisible?"UPI QR Active":"Payment dialog detected"}</div>
          <div style="margin-top:6px; color:#15803d; font-weight:600;">Ads Control Assistant is now displayed on the Meta page!</div>
        </div>
      `:o.innerHTML=`
        <div class="feedback-card feedback-card--warn">
          <div class="feedback-title">⚠️ QR Not Found on Active Tab</div>
          <div>${(t==null?void 0:t.error)||'Make sure the Meta "Add Funds" or UPI Payment QR modal is open on screen, then click Detect again.'}</div>
        </div>
      `}catch(n){o.innerHTML=`<div class="feedback-card feedback-card--error"><div class="feedback-title">Scan Error</div>${(n==null?void 0:n.message)||"Could not scan tab."}</div>`}finally{a.disabled=!1,a.textContent="🔍 Detect QR on Current Tab"}}function u(o,a=!0,n,t=!0){s.innerHTML=`
    <header>
      <div class="brand">
        <div class="brand-icon">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
        </div>
        <strong>Ads Control Companion</strong>
      </div>
      <span id="conn-status" class="status ${a?"":"status--warn"}">${a?"Connected":"Offline"}</span>
    </header>
    <section>
      <!-- Auto-detect Toggle -->
      <label class="toggle-row" for="auto-detect-switch">
        <div class="toggle-label">
          <span class="toggle-title">Auto-Detect Payment QR</span>
          <span class="toggle-sub">Automatically shows assistant when Meta QR opens</span>
        </div>
        <div class="switch">
          <input type="checkbox" id="auto-detect-switch" ${t?"checked":""}>
          <span class="slider"></span>
        </div>
      </label>

      <dl>
        <dt>Device</dt>
        <dd>${o||"Connected browser"}</dd>
        ${n?`<dt>Renews</dt><dd>${new Date(n).toLocaleDateString()}</dd>`:""}
      </dl>

      <button id="scan-btn" type="button">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        Detect QR on Current Tab
      </button>
      <div id="scan-feedback"></div>

      <button id="disconnect-btn" class="secondary" type="button">Disconnect Browser</button>
      <p class="hint">Keep the Meta payment modal open while mapping funds.</p>
    </section>
  `;const e=s.querySelector("#auto-detect-switch");e.addEventListener("change",async()=>{const l=e.checked;await chrome.storage.local.set({autoDetectQr:l}),i({type:"SET_SETTINGS",settings:{autoDetectQr:l}})});const c=s.querySelector("#scan-btn"),r=s.querySelector("#scan-feedback");c.addEventListener("click",()=>void g(r,c)),s.querySelector("#disconnect-btn").addEventListener("click",async()=>{confirm("Disconnect this browser from ADS Control?")&&(await i({type:"DISCONNECT"}),d("Browser disconnected. Generate a new code in Meta Funding → Devices to pair again."))})}function d(o=""){s.innerHTML=`
    <header>
      <strong>Ads Control Companion</strong>
      <span class="status status--muted">Not paired</span>
    </header>
    <form>
      <label>One-time pairing code
        <input name="code" autocomplete="off" required placeholder="Paste pairing code from ADS Control">
      </label>
      <label>Device name
        <input name="deviceName" required value="Chrome on this PC">
      </label>
      <button type="submit">Pair Extension</button>
      ${o?`<p class="error" role="alert">${o}</p>`:""}
      <p class="hint">Generate a 6-digit code in Meta Funding → Devices page.</p>
    </form>
  `,s.querySelector("form").addEventListener("submit",async a=>{a.preventDefault();const n=new FormData(a.currentTarget),t=s.querySelector("button");t.disabled=!0,t.textContent="Pairing...";const e=await i({type:"PAIR",code:n.get("code"),deviceName:n.get("deviceName")});e!=null&&e.error?d(e.error):u(e.deviceId,!0,void 0,!0)})}chrome.storage.local.get(["deviceSession","autoDetectQr"]).then(({deviceSession:o,autoDetectQr:a})=>{const n=a!==!1;o&&new Date(o.expiresAt).getTime()>Date.now()?(u(o.deviceId,!0,o.expiresAt,n),i({type:"PAIRING_STATUS"}).then(t=>{const e=document.querySelector("#conn-status");if(e){const c=(t==null?void 0:t.online)!==!1;e.className=`status ${c?"":"status--warn"}`,e.textContent=c?"Connected":"Offline"}})):d()}).catch(()=>{d()});
