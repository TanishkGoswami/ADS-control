(function() {
  "use strict";
  const styles = ':host {\n  all: initial;\n  color: #1c1e21;\n  font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;\n  font-size: 13px;\n  line-height: 1.45;\n  -webkit-font-smoothing: antialiased;\n}\n\n.ac-panel {\n  position: fixed;\n  z-index: 2147483647;\n  right: 20px;\n  bottom: 20px;\n  width: min(350px, calc(100vw - 32px));\n  background: #ffffff;\n  border: 1px solid #e4e7eb;\n  border-radius: 8px;\n  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);\n  overflow: hidden;\n  box-sizing: border-box;\n}\n\n.ac-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  padding: 12px 14px;\n  background: #f8fafc;\n  border-bottom: 1px solid #e4e7eb;\n}\n\n.ac-brand {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.ac-logo-badge {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 5px;\n  background: #0064e0;\n  color: #ffffff;\n}\n\n.ac-title {\n  font-size: 12.5px;\n  font-weight: 700;\n  color: #0f172a;\n  letter-spacing: -0.01em;\n}\n\n.ac-header-actions {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.ac-badge {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  padding: 2px 7px;\n  border-radius: 4px;\n  font-size: 10.5px;\n  font-weight: 600;\n  letter-spacing: 0.02em;\n}\n\n.ac-badge--success {\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #065f46;\n}\n\n.ac-badge--warn {\n  background: #fffbeb;\n  border: 1px solid #fde68a;\n  color: #92400e;\n}\n\n.ac-badge--danger {\n  background: #fef2f2;\n  border: 1px solid #fecaca;\n  color: #991b1b;\n}\n\n.ac-badge--muted {\n  background: #f1f5f9;\n  border: 1px solid #e2e8f0;\n  color: #64748b;\n}\n\n.ac-close {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  padding: 0;\n  border: none;\n  border-radius: 4px;\n  background: transparent;\n  color: #64748b;\n  font-size: 18px;\n  cursor: pointer;\n  transition: background 0.15s, color 0.15s;\n}\n\n.ac-close:hover {\n  background: #e2e8f0;\n  color: #0f172a;\n}\n\n.ac-body {\n  padding: 12px 14px 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n\n.ac-card {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding: 10px 12px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 6px;\n}\n\n.ac-row {\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n  gap: 12px;\n  font-size: 11.5px;\n}\n\n.ac-label {\n  color: #64748b;\n  font-weight: 500;\n  flex-shrink: 0;\n}\n\n.ac-val-wrap {\n  text-align: right;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.ac-val {\n  color: #0f172a;\n  font-weight: 600;\n  font-variant-numeric: tabular-nums;\n  word-break: break-word;\n}\n\n.ac-detail {\n  display: block;\n  font-size: 10px;\n  color: #94a3b8;\n  font-weight: 400;\n}\n\n.ac-alert {\n  padding: 8px 10px;\n  border-radius: 5px;\n  font-size: 11px;\n  line-height: 1.4;\n}\n\n.ac-alert--info {\n  background: #eff6ff;\n  border: 1px solid #bfdbfe;\n  color: #1e40af;\n}\n\n.ac-alert--error {\n  background: #fef2f2;\n  border: 1px solid #fecaca;\n  color: #991b1b;\n}\n\n.ac-alert--success {\n  background: #f0fdf4;\n  border: 1px solid #bbf7d0;\n  color: #166534;\n}\n\n.ac-field {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n\n.ac-field-label {\n  font-size: 11px;\n  font-weight: 600;\n  color: #475569;\n}\n\n.ac-select {\n  box-sizing: border-box;\n  width: 100%;\n  height: 34px;\n  padding: 0 8px;\n  border: 1px solid #cbd5e1;\n  border-radius: 5px;\n  background: #ffffff;\n  color: #0f172a;\n  font-size: 11.5px;\n  outline: none;\n  transition: border-color 0.15s;\n}\n\n.ac-select:focus {\n  border-color: #0064e0;\n}\n\n.ac-button {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 34px;\n  padding: 0 12px;\n  border: 1px solid #0064e0;\n  border-radius: 5px;\n  background: #0064e0;\n  color: #ffffff;\n  font-size: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 0.15s;\n}\n\n.ac-button:hover:not(:disabled) {\n  background: #0052b8;\n}\n\n.ac-button:disabled {\n  opacity: 0.55;\n  cursor: not-allowed;\n}\n\n.ac-feedback-area {\n  margin-top: 4px;\n}\n';
  const ACCOUNT_KEYS = ["act", "account_id", "ad_account_id", "asset_id", "payment_account_id", "selected_account_id"];
  const APPROVED_HOST_SUFFIXES = ["facebook.com", "meta.com"];
  function normalizeMetaAccountId(value) {
    if (!value) return void 0;
    const digits = value.replace(/^act_/i, "").replace(/\D/g, "");
    return /^\d{5,32}$/.test(digits) ? digits : void 0;
  }
  function extractUrlAccountId(rawUrl) {
    try {
      const url = new URL(rawUrl);
      for (const key of ACCOUNT_KEYS) {
        const accountId = normalizeMetaAccountId(url.searchParams.get(key));
        if (accountId) return accountId;
      }
      const pathMatch = /(?:act[_-]|account[_-])?(\d{8,32})/i.exec(url.pathname);
      if (pathMatch && pathMatch[1]) {
        const candidate = normalizeMetaAccountId(pathMatch[1]);
        if (candidate) return candidate;
      }
    } catch {
      return void 0;
    }
    return void 0;
  }
  function isApprovedBillingUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (url.protocol !== "https:") return false;
      const hostname = url.hostname.toLowerCase();
      const isMetaHost = APPROVED_HOST_SUFFIXES.some((suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`));
      if (!isMetaHost) return false;
      if (hostname.includes("adsmanager") || hostname.includes("business")) return true;
      const path = url.pathname.toLowerCase();
      const isBillingOrAdsPath = ["/billing", "/billing_hub", "/payments", "/payment_settings", "/ads", "/adsmanager", "/manage"].some((segment) => path.includes(segment));
      const hasAccountParam = ACCOUNT_KEYS.some((k) => Boolean(url.searchParams.get(k)));
      return isBillingOrAdsPath || hasAccountParam;
    } catch {
      return false;
    }
  }
  function first(root, selectors) {
    for (const selector of selectors) {
      const found = root.querySelector(selector);
      if (found) return found;
    }
    return null;
  }
  function cleanText(element, maxLength) {
    var _a;
    const text = (_a = element == null ? void 0 : element.textContent) == null ? void 0 : _a.replace(/\s+/g, " ").trim();
    return text ? text.slice(0, maxLength) : void 0;
  }
  function findModalDialog(doc) {
    var _a, _b, _c, _d, _e;
    const explicitSignal = doc.querySelector('[data-ads-control-signal="payment-dialog"]');
    if (explicitSignal) return explicitSignal;
    const candidates = Array.from(((_a = doc.querySelectorAll) == null ? void 0 : _a.call(doc, '[role="dialog"], [aria-modal="true"], div[class*="dialog" i], div[class*="modal" i]')) ?? []);
    for (const el of candidates) {
      const text = ((_b = el.textContent) == null ? void 0 : _b.toLowerCase()) || "";
      if (text.includes("complete payment") || text.includes("add funds") || text.includes("payment request expires") || text.includes("upi") || text.includes("scan qr")) {
        return el;
      }
    }
    if (candidates.length > 0) return candidates[0];
    const allDivs = Array.from(((_c = doc.querySelectorAll) == null ? void 0 : _c.call(doc, "div, section, main")) ?? []);
    for (const el of allDivs) {
      const text = ((_d = el.textContent) == null ? void 0 : _d.toLowerCase()) || "";
      if (text.includes("complete payment") && (text.includes("expires") || text.includes("upi") || text.includes("phonepe") || text.includes("paytm"))) {
        return el;
      }
    }
    return ((_e = doc.querySelector) == null ? void 0 : _e.call(doc, "body")) ?? null;
  }
  function extractModalAccount(root) {
    var _a, _b, _c;
    const explicitId = root.querySelector('[data-ads-control-signal="account-id"]');
    const explicitName = cleanText(root.querySelector('[data-ads-control-signal="account-name"]'), 120);
    const normalizedExplicitId = normalizeMetaAccountId((explicitId == null ? void 0 : explicitId.getAttribute("data-account-id")) || cleanText(explicitId, 40));
    if (normalizedExplicitId || explicitName) return { id: normalizedExplicitId, name: explicitName };
    const elements = ((_a = root.querySelectorAll) == null ? void 0 : _a.call(root, "span, div, p, h1, h2, h3, h4, b, strong")) ?? [];
    for (const element of elements) {
      const text = ((_b = element.textContent) == null ? void 0 : _b.replace(/\s+/g, " ").trim()) || "";
      if (!text || text.length > 120) continue;
      const match = /^([^(]+?)\s*\((\d{8,32})\)$/.exec(text);
      if (match) {
        const id = normalizeMetaAccountId(match[2]);
        const name = match[1].trim();
        if (id) return { id, name };
      }
    }
    for (const element of elements) {
      const text = ((_c = element.textContent) == null ? void 0 : _c.replace(/\s+/g, " ").trim()) || "";
      const match = /(?:account\s*(?:id|#)?\s*[:\s]*)?(\d{8,32})/i.exec(text);
      if (match && match[1]) {
        const id = normalizeMetaAccountId(match[1]);
        if (id) return { id, name: "Meta Ad Account" };
      }
    }
    return {};
  }
  function parseInrAmount(text) {
    if (!text) return void 0;
    const cleaned = text.replace(/[\s\u00A0\u200B-\u200D\uFEFF]+/g, " ").trim();
    if (!cleaned) return void 0;
    const explicitMatch = /(?:₹|INR|Rs\.?|\u20B9)\s*([0-9]{1,3}(?:,[0-9]{2,3})*(?:\.\d{1,2})?|[0-9]+(?:\.\d{1,2})?)/i.exec(cleaned) || /([0-9]{1,3}(?:,[0-9]{2,3})*(?:\.\d{1,2})?|[0-9]+(?:\.\d{1,2})?)\s*(?:INR|₹|\u20B9)/i.exec(cleaned);
    if (explicitMatch) {
      const rawNum = explicitMatch[1].replace(/,/g, "");
      const parts = /^(\d+)(?:\.(\d{1,2}))?$/.exec(rawNum);
      if (parts) {
        const minor = BigInt(parts[1]) * 100n + BigInt((parts[2] ?? "").padEnd(2, "0").slice(0, 2) || "0");
        if (minor > 0n) {
          const formatted = `₹${Number(parts[1]).toLocaleString("en-IN")}${parts[2] ? "." + parts[2].padEnd(2, "0").slice(0, 2) : ".00"}`;
          return { amountText: formatted, amountMinor: minor.toString() };
        }
      }
    }
    const standaloneMatch = /(?:^|\s)([0-9]{1,3}(?:,[0-9]{2,3})+(?:\.\d{1,2})?|[0-9]{2,8}\.\d{2})(?:\s|$)/.exec(cleaned);
    if (standaloneMatch) {
      const rawNum = standaloneMatch[1].replace(/,/g, "");
      const parts = /^(\d+)(?:\.(\d{1,2}))?$/.exec(rawNum);
      if (parts) {
        const minor = BigInt(parts[1]) * 100n + BigInt((parts[2] ?? "").padEnd(2, "0").slice(0, 2) || "0");
        if (minor > 0n && minor < 100000000000n) {
          const formatted = `₹${Number(parts[1]).toLocaleString("en-IN")}${parts[2] ? "." + parts[2].padEnd(2, "0").slice(0, 2) : ".00"}`;
          return { amountText: formatted, amountMinor: minor.toString() };
        }
      }
    }
    return void 0;
  }
  function extractModalAmount(modal) {
    var _a, _b, _c;
    const explicitAmount = cleanText(modal.querySelector('[data-ads-control-signal="amount"]'), 80);
    const explicitParsed = parseInrAmount(explicitAmount);
    if (explicitParsed) return { ...explicitParsed, currencyCode: "INR" };
    const candidates = ((_a = modal.querySelectorAll) == null ? void 0 : _a.call(modal, "h1, h2, h3, h4, div, span, b, strong, p")) ?? [];
    for (const el of candidates) {
      const text = ((_b = el.textContent) == null ? void 0 : _b.trim()) || "";
      if (!text || text.length > 50) continue;
      if (/^\d{10,}$/.test(text) || /\b202\d\b/.test(text) || /\b\d{1,2}:\d{2}\b/.test(text)) continue;
      if (text.includes("₹") || /INR|Rs/i.test(text)) {
        const parsed2 = parseInrAmount(text);
        if (parsed2) return { ...parsed2, currencyCode: "INR" };
      }
    }
    for (const el of candidates) {
      const text = ((_c = el.textContent) == null ? void 0 : _c.trim()) || "";
      if (!text || text.length > 30 || text.length < 3) continue;
      if (/^\d{10,}$/.test(text) || /\b202\d\b/.test(text) || /\b\d{1,2}:\d{2}\b/.test(text)) continue;
      const parsed2 = parseInrAmount(text);
      if (parsed2) return { ...parsed2, currencyCode: "INR" };
    }
    const fullText = cleanText(modal, 2e4) || "";
    const parsed = parseInrAmount(fullText);
    if (parsed) return { ...parsed, currencyCode: "INR" };
    return void 0;
  }
  function stateFor(dialog, rules) {
    var _a;
    if (first(dialog, rules.selectors.success)) return "success";
    if (first(dialog, rules.selectors.failure)) return "failure";
    if (first(dialog, rules.selectors.expired)) return "expired";
    if (first(dialog, rules.selectors.processing)) return "processing";
    const text = ((_a = dialog.textContent) == null ? void 0 : _a.replace(/\s+/g, " ").toLowerCase()) ?? "";
    if (text.includes("payment successful") || text.includes("funds added") || text.includes("transaction complete") || text.includes("payment complete")) {
      return "success";
    }
    if (text.includes("payment failed") || text.includes("transaction failed") || text.includes("declined")) {
      return "failure";
    }
    if (text.includes("qr code expired") || text.includes("payment request expired") || text.includes("session expired")) {
      return "expired";
    }
    const hasQrElement = Boolean(first(dialog, rules.selectors.qr));
    const hasUpiText = text.includes("complete payment") || text.includes("payment request expires") || text.includes("upi") || text.includes("phonepe") || text.includes("googlepay") || text.includes("paytm") || text.includes("bhim") || text.includes("scan qr") || text.includes("scan the qr") || text.includes("all supported apps");
    if (hasQrElement || hasUpiText) return "qr-active";
    return "unknown";
  }
  function extractPaymentMethod(dialog) {
    var _a, _b, _c, _d;
    const text = ((_a = dialog.textContent) == null ? void 0 : _a.toLowerCase()) || "";
    if (text.includes("phonepe") || text.includes("googlepay") || text.includes("paytm") || text.includes("bhim") || text.includes("upi") || text.includes("scan qr")) {
      return "UPI (Dynamic QR)";
    }
    const checkedRadios = Array.from(((_b = dialog.querySelectorAll) == null ? void 0 : _b.call(dialog, 'input[type="radio"]:checked, [role="radio"][aria-checked="true"], [aria-selected="true"]')) ?? []);
    for (const radio of checkedRadios) {
      const parentText = ((_d = (_c = radio.parentElement) == null ? void 0 : _c.textContent) == null ? void 0 : _d.replace(/\s+/g, " ").trim()) || "";
      if (parentText) return parentText.slice(0, 40);
    }
    if (text.includes("visa") || text.includes("mastercard") || text.includes("debit or credit card")) {
      return "Credit / Debit Card";
    }
    if (text.includes("net banking") || text.includes("netbanking")) {
      return "Net Banking";
    }
    return "UPI";
  }
  function parseDomSignals(documentLike, rules) {
    if (rules.disabled) return { qrVisible: false, dialogState: "unknown", successVisible: false, signalNames: [] };
    const dialog = findModalDialog(documentLike);
    if (!dialog) return { qrVisible: false, dialogState: "unknown", successVisible: false, signalNames: [] };
    const dialogState = stateFor(dialog, rules);
    const qrVisible = Boolean(first(dialog, rules.selectors.qr)) || dialogState === "qr-active";
    const accountInfo = extractModalAccount(dialog);
    const amount = extractModalAmount(dialog);
    const paymentMethod = extractPaymentMethod(dialog);
    const signalNames = [
      "payment-dialog",
      ...accountInfo.id ? ["visible-account-id"] : [],
      ...accountInfo.name ? ["visible-account-name"] : [],
      ...amount ? ["inr-amount"] : [],
      ...qrVisible ? ["qr-present"] : [],
      ...dialogState !== "unknown" && dialogState !== "qr-active" ? [`state-${dialogState}`] : []
    ];
    return {
      ...accountInfo.id ? { visibleAccountId: accountInfo.id } : {},
      ...accountInfo.name ? { visibleAccountName: accountInfo.name } : {},
      ...amount ? amount : {},
      paymentMethod,
      qrVisible,
      dialogState,
      successVisible: dialogState === "success",
      signalNames
    };
  }
  const DEFAULT_DETECTOR_RULES = {
    version: "fixture-v2",
    disabled: false,
    selectors: {
      dialog: [
        '[data-ads-control-signal="payment-dialog"]',
        '[role="dialog"][aria-modal="true"]',
        '[role="dialog"]',
        'div[aria-modal="true"]',
        'div[data-testid*="payment"]',
        'div[class*="PaymentDialog"]',
        'div[class*="Modal"]',
        "body"
      ],
      accountId: ['[data-ads-control-signal="account-id"]', '[data-testid*="account-id"]', "[data-account-id]"],
      accountName: ['[data-ads-control-signal="account-name"]', '[data-testid*="account-name"]'],
      amount: ['[data-ads-control-signal="amount"]', '[data-testid*="amount"]', 'input[name="amount"]'],
      qr: [
        '[data-ads-control-signal="qr"]',
        "canvas",
        'img[src*="qr" i]',
        'img[alt*="qr" i]',
        'img[src*="data:image"]',
        'svg[class*="qr" i]',
        '[class*="qr" i]',
        '[id*="qr" i]',
        '[data-testid*="qr" i]',
        '[aria-label*="qr" i]'
      ],
      processing: ['[data-ads-control-state="processing"]', '[data-testid*="processing"]'],
      success: ['[data-ads-control-state="success"]', '[data-testid*="success"]'],
      failure: ['[data-ads-control-state="failure"]', '[data-testid*="failure"]'],
      expired: ['[data-ads-control-state="expired"]', '[data-testid*="expired"]']
    }
  };
  function confidence(urlId, visibleId, visibleName) {
    if (urlId && visibleId && urlId !== visibleId) return { confidence: "blocked", blocked: true, requiresConfirmation: true };
    if (urlId && visibleId) return { confidence: "high", blocked: false, requiresConfirmation: false };
    if (visibleId || visibleName) return { confidence: "medium", blocked: false, requiresConfirmation: true };
    return { confidence: "low", blocked: false, requiresConfirmation: true };
  }
  function hashSnapshot(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function evaluateDetection(pageUrl, documentLike, rules = DEFAULT_DETECTOR_RULES) {
    const dom = parseDomSignals(documentLike, rules);
    if (!dom.signalNames.includes("payment-dialog")) return null;
    if (dom.dialogState === "unknown" && !dom.qrVisible) return null;
    const urlAccountId = extractUrlAccountId(pageUrl);
    const result = confidence(urlAccountId, dom.visibleAccountId, dom.visibleAccountName);
    const safe = {
      pageUrl,
      ...urlAccountId ? { urlAccountId } : {},
      ...dom,
      ...result,
      detectorVersion: rules.version
    };
    return { ...safe, snapshotHash: hashSnapshot(JSON.stringify(safe)) };
  }
  function isDetectionEvidence(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    const allowed = /* @__PURE__ */ new Set([
      "pageUrl",
      "urlAccountId",
      "visibleAccountId",
      "visibleAccountName",
      "amountText",
      "amountMinor",
      "paymentMethod",
      "currencyCode",
      "qrVisible",
      "dialogState",
      "successVisible",
      "signalNames",
      "confidence",
      "blocked",
      "requiresConfirmation",
      "detectorVersion",
      "snapshotHash"
    ]);
    return Object.keys(candidate).every((key) => allowed.has(key)) && typeof candidate.pageUrl === "string" && typeof candidate.qrVisible === "boolean" && Array.isArray(candidate.signalNames) && typeof candidate.snapshotHash === "string";
  }
  const money = (minor) => minor ? new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(Number(minor) / 100) : "Amount unavailable";
  const shortId = (id) => id && id.length > 4 ? `ID: ...${id.slice(-4)}` : id ? `ID: ${id}` : "";
  function row(label, value, detail) {
    const item = document.createElement("div");
    item.className = "ac-row";
    const key = document.createElement("span");
    key.className = "ac-label";
    key.textContent = label;
    const content = document.createElement("div");
    content.className = "ac-val-wrap";
    const strong = document.createElement("strong");
    strong.className = "ac-val";
    strong.textContent = value;
    content.append(strong);
    if (detail) {
      const small = document.createElement("span");
      small.className = "ac-detail";
      small.textContent = detail;
      content.append(small);
    }
    item.append(key, content);
    return item;
  }
  function field(label, control) {
    const wrap = document.createElement("label");
    wrap.className = "ac-field";
    const text = document.createElement("span");
    text.className = "ac-field-label";
    text.textContent = label;
    wrap.append(text, control);
    return wrap;
  }
  function button(label) {
    const el = document.createElement("button");
    el.type = "button";
    el.className = "ac-button";
    el.textContent = label;
    return el;
  }
  function message(text, tone = "info") {
    const el = document.createElement("div");
    el.className = `ac-alert ac-alert--${tone}`;
    el.textContent = text;
    return el;
  }
  function renderOverlay(container, evidence, context, send, onClose) {
    var _a, _b, _c, _d, _e;
    container.replaceChildren();
    const account = ((_a = context.accounts) == null ? void 0 : _a.find((item) => item.id === context.exactAccountId)) || ((_b = context.accounts) == null ? void 0 : _b[0]);
    const detectedName = evidence.visibleAccountName || (account == null ? void 0 : account.internalAlias) || (account == null ? void 0 : account.name) || "Meta Ad Account";
    const detectedId = evidence.visibleAccountId || evidence.urlAccountId || (account == null ? void 0 : account.metaAdAccountId);
    const header = document.createElement("div");
    header.className = "ac-header";
    const brand = document.createElement("div");
    brand.className = "ac-brand";
    brand.innerHTML = `
    <div class="ac-logo-badge">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
    </div>
    <span class="ac-title">Ads Control Companion</span>
  `;
    const actions = document.createElement("div");
    actions.className = "ac-header-actions";
    const status = document.createElement("span");
    if (evidence.blocked) {
      status.className = "ac-badge ac-badge--danger";
      status.textContent = "Mismatch";
    } else if (!context.paired) {
      status.className = "ac-badge ac-badge--muted";
      status.textContent = "Not paired";
    } else if (context.exactAccountId || ((_c = context.accounts) == null ? void 0 : _c.length)) {
      status.className = "ac-badge ac-badge--success";
      status.textContent = "Connected";
    } else {
      status.className = "ac-badge ac-badge--warn";
      status.textContent = "Unsynced";
    }
    const close = document.createElement("button");
    close.type = "button";
    close.className = "ac-close";
    close.title = "Close assistant";
    close.setAttribute("aria-label", "Close assistant");
    close.innerHTML = "&times;";
    close.onclick = onClose;
    actions.append(status, close);
    header.append(brand, actions);
    const body = document.createElement("div");
    body.className = "ac-body";
    const card = document.createElement("div");
    card.className = "ac-card";
    card.append(
      row("Ad Account", detectedName, shortId(detectedId)),
      row("Payment Amount", evidence.amountText || "Not detected"),
      row("Payment Method", evidence.paymentMethod || (evidence.qrVisible ? "UPI (Dynamic QR)" : "Auto-detected")),
      row("QR State", evidence.qrVisible ? "UPI QR Active" : "Dialog detected")
    );
    body.append(card);
    if (!context.paired) {
      body.append(message("Browser is not paired with ADS Control. Click the extension icon to connect.", "error"));
    } else if (evidence.blocked) {
      body.append(message("The account in the URL and payment dialog do not match. Fund mapping is blocked for safety.", "error"));
    } else if (!context.exactAccountId && (!context.accounts || context.accounts.length === 0)) {
      body.append(message(`${detectedName} (${shortId(detectedId)}) is not linked in ADS Control. Please sync Meta assets in dashboard.`, "error"));
    } else if (!evidence.amountMinor || evidence.currencyCode !== "INR") {
      body.append(message("Waiting for valid INR payment amount from Meta modal...", "info"));
    } else {
      const targetAccountId = context.exactAccountId || ((_e = (_d = context.accounts) == null ? void 0 : _d[0]) == null ? void 0 : _e.id);
      const source = document.createElement("select");
      source.className = "ac-select";
      source.append(new Option("-- Select Approved Funding Source --", ""));
      for (const request of context.requests ?? []) {
        if (request.amountMinor !== evidence.amountMinor || request.targetAdAccountId && request.targetAdAccountId !== targetAccountId) {
          continue;
        }
        source.append(new Option(`Request: ${request.referenceCode} · ${request.purpose} (${money(request.amountMinor)})`, `FUNDING_REQUEST:${request.id}`));
      }
      for (const lot of context.lots ?? []) {
        if (BigInt(lot.availableAmountMinor || "0") < BigInt(evidence.amountMinor)) continue;
        source.append(new Option(`Prepaid Lot: Available ${money(lot.availableAmountMinor)}`, `FUND_LOT:${lot.id}`));
      }
      body.append(field("Funding Allocation Source", source));
      if (source.options.length === 1) {
        body.append(message(`No approved funding source covers ${money(evidence.amountMinor)}. Create & approve a request in ADS Control first.`, "error"));
      }
      const map = button("⚡ Map Approved Funds");
      map.disabled = true;
      source.onchange = () => {
        map.disabled = !source.value;
      };
      const feedback = document.createElement("div");
      feedback.className = "ac-feedback-area";
      map.onclick = async () => {
        map.disabled = true;
        feedback.replaceChildren(message("Mapping funds to top-up session...", "info"));
        const [sourceType, sourceId] = source.value.split(":");
        const result = await send({
          type: "MAP_TOPUP",
          evidence,
          selectedAdAccountId: targetAccountId,
          sourceType,
          sourceId
        });
        if (result == null ? void 0 : result.error) {
          map.disabled = false;
          feedback.replaceChildren(message(result.error, "error"));
        } else {
          feedback.replaceChildren(message("Funds mapped successfully! Proceed to scan and pay in Meta.", "success"));
        }
      };
      body.append(map, feedback);
    }
    container.append(header, body);
  }
  const HOST_ID = "ads-control-companion-root";
  let observer;
  let timer;
  let lastSnapshot = "";
  let lastUrl = location.href;
  let dismissedForCurrentPayment = false;
  async function isAutoDetectEnabled() {
    try {
      const result = await chrome.storage.local.get("autoDetectQr");
      return result.autoDetectQr !== false;
    } catch {
      return true;
    }
  }
  function removeAssistant() {
    var _a;
    observer == null ? void 0 : observer.disconnect();
    observer = void 0;
    (_a = document.getElementById(HOST_ID)) == null ? void 0 : _a.remove();
    lastSnapshot = "";
  }
  function overlayContainer() {
    let host = document.getElementById(HOST_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.setAttribute("aria-live", "polite");
      document.documentElement.append(host);
      const shadow = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = styles;
      const panel = document.createElement("aside");
      panel.className = "ac-panel";
      panel.setAttribute("aria-label", "Ads Control payment assistant");
      shadow.append(style, panel);
    }
    return host.shadowRoot.querySelector(".ac-panel");
  }
  async function inspect(force = false) {
    var _a;
    if (!isApprovedBillingUrl(location.href)) {
      removeAssistant();
      return { visible: false, error: "Current tab is not a Meta Ads Manager / Billing page." };
    }
    if (!force) {
      const autoDetect = await isAutoDetectEnabled();
      if (!autoDetect) return { visible: false, autoDetectDisabled: true };
    }
    const evidence = evaluateDetection(location.href, document);
    if (!evidence) {
      if (!force) {
        (_a = document.getElementById(HOST_ID)) == null ? void 0 : _a.remove();
        lastSnapshot = "";
        dismissedForCurrentPayment = false;
      }
      return {
        visible: false,
        error: "Payment QR screen not detected. Open Meta UPI / Add Funds modal and try again."
      };
    }
    if (dismissedForCurrentPayment && !force) return { visible: false, dismissed: true };
    if (!isDetectionEvidence(evidence)) return { visible: false, error: "Invalid detection evidence" };
    const hostPresent = Boolean(document.getElementById(HOST_ID));
    if (!force && hostPresent && evidence.snapshotHash === lastSnapshot) {
      return { visible: true, cached: true };
    }
    lastSnapshot = evidence.snapshotHash;
    dismissedForCurrentPayment = false;
    const context = await chrome.runtime.sendMessage({ type: "GET_CONTEXT", evidence }).catch(() => ({ paired: false }));
    renderOverlay(overlayContainer(), evidence, context, (message2) => chrome.runtime.sendMessage(message2), () => {
      var _a2;
      dismissedForCurrentPayment = true;
      (_a2 = document.getElementById(HOST_ID)) == null ? void 0 : _a2.remove();
    });
    void chrome.runtime.sendMessage({ type: "META_TOPUP_DETECTION", evidence }).catch(() => void 0);
    return {
      visible: true,
      url: location.href,
      account: evidence.visibleAccountId || evidence.urlAccountId || "Unknown Account",
      accountName: evidence.visibleAccountName,
      amount: evidence.amountText || "Not detected",
      qrVisible: evidence.qrVisible,
      dialogState: evidence.dialogState
    };
  }
  function scheduleInspect() {
    if (timer !== void 0) window.clearTimeout(timer);
    timer = window.setTimeout(() => void inspect(false), 80);
  }
  function startForRoute() {
    observer == null ? void 0 : observer.disconnect();
    if (!isApprovedBillingUrl(location.href)) {
      removeAssistant();
      return;
    }
    observer = new MutationObserver(scheduleInspect);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["aria-hidden", "aria-modal", "style", "class", "hidden"]
    });
    void inspect(false);
  }
  const scriptVersion = chrome.runtime.getManifest().version;
  if (window.top === window) {
    chrome.runtime.onMessage.addListener((message2, _sender, sendResponse) => {
      if ((message2 == null ? void 0 : message2.type) === "ADS_CONTROL_PING") {
        sendResponse({ active: true, version: scriptVersion });
        return false;
      }
      if ((message2 == null ? void 0 : message2.type) === "ADS_CONTROL_SCAN") {
        lastSnapshot = "";
        dismissedForCurrentPayment = false;
        inspect(true).then((result) => sendResponse(result)).catch((error) => sendResponse({ visible: false, error: error instanceof Error ? error.message : "Scan failed" }));
        return true;
      }
      return false;
    });
    window.setInterval(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        startForRoute();
      } else if (isApprovedBillingUrl(location.href)) {
        void inspect(false);
      }
    }, 350);
    window.addEventListener("popstate", startForRoute);
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.autoDetectQr) {
        void inspect(false);
      }
    });
    startForRoute();
  }
})();
