var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  class ApiError extends Error {
    constructor(status, message) {
      super(message);
      this.status = status;
    }
  }
  class ExtensionApi {
    constructor(baseUrl, getSession2) {
      this.baseUrl = baseUrl;
      this.getSession = getSession2;
    }
    async request(path, init = {}, authenticated = true) {
      const session = authenticated ? await this.getSession() : void 0;
      const response = await fetch(`${this.baseUrl}${path}`, {
        ...init,
        headers: { "Content-Type": "application/json", ...session ? { Authorization: `Bearer ${session.token}` } : {}, ...init.headers }
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new ApiError(response.status, body.message || `Ads Control API returned ${response.status}`);
      }
      return response.json();
    }
  }
  const ACCOUNT_KEYS = ["act", "account_id", "ad_account_id", "asset_id", "payment_account_id", "selected_account_id"];
  const APPROVED_HOST_SUFFIXES = ["facebook.com", "meta.com"];
  function normalizeMetaAccountId(value) {
    if (!value) return void 0;
    const digits = value.replace(/^act_/i, "").replace(/\D/g, "");
    return /^\d{5,32}$/.test(digits) ? digits : void 0;
  }
  function isApprovedBillingUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (url.protocol !== "https:") return false;
      const hostname = url.hostname.toLowerCase();
      const isMetaHost = APPROVED_HOST_SUFFIXES.some((suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`));
      if (!isMetaHost) return false;
      if (hostname.includes("adsmanager") || hostname.includes("business")) return true;
      const path = url.pathname.toLowerCase();
      const isBillingOrAdsPath = ["/billing", "/billing_hub", "/payments", "/payment_settings", "/ads", "/adsmanager", "/manage"].some((segment) => path.includes(segment));
      const hasAccountParam = ACCOUNT_KEYS.some((k) => Boolean(url.searchParams.get(k)));
      return isBillingOrAdsPath || hasAccountParam;
    } catch {
      return false;
    }
  }
  const KEY = "topupEventQueue";
  const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
  class DurableEventQueue {
    constructor(store, now = () => Date.now(), random = Math.random) {
      __publicField(this, "draining", false);
      __publicField(this, "store");
      __publicField(this, "now");
      __publicField(this, "random");
      this.store = store;
      this.now = now;
      this.random = random;
    }
    async list() {
      const value = await this.store.get(KEY);
      return Array.isArray(value[KEY]) ? value[KEY] : [];
    }
    async enqueue(input) {
      const now = this.now();
      const items = (await this.list()).filter((item) => now - item.createdAt < MAX_AGE_MS && item.id !== input.id);
      items.push({ ...input, createdAt: now, attempts: 0, nextAttemptAt: now });
      await this.store.set({ [KEY]: items.slice(-100) });
    }
    async drain(send) {
      if (this.draining) return { sent: 0, paused: false };
      this.draining = true;
      let sent = 0;
      let paused = false;
      try {
        const now = this.now();
        const source = (await this.list()).filter((item) => now - item.createdAt < MAX_AGE_MS);
        const remaining = [];
        for (let index = 0; index < source.length; index += 1) {
          const item = source[index];
          if (item.nextAttemptAt > now) {
            remaining.push(item);
            continue;
          }
          try {
            await send(item);
            sent += 1;
          } catch (error) {
            if ((error == null ? void 0 : error.status) === 401 || (error == null ? void 0 : error.status) === 403) {
              remaining.push(item, ...source.slice(index + 1));
              paused = true;
              break;
            }
            const attempts = item.attempts + 1;
            remaining.push({ ...item, attempts, nextAttemptAt: now + Math.min(15 * 6e4, 2 ** attempts * 5e3) + Math.floor(this.random() * 1e3) });
          }
        }
        await this.store.set({ [KEY]: remaining });
        return { sent, paused };
      } finally {
        this.draining = false;
      }
    }
  }
  const API_BASE = "http://127.0.0.1:4000/api/v1";
  const HEARTBEAT_ALARM = "ads-control-heartbeat";
  const RETRY_ALARM = "ads-control-event-retry";
  const storage = { get: (key) => chrome.storage.local.get(key), set: (value) => chrome.storage.local.set(value) };
  const getSession = async () => (await chrome.storage.local.get("deviceSession")).deviceSession;
  const api = new ExtensionApi(API_BASE, getSession);
  const queue = new DurableEventQueue(storage);
  function approved(raw) {
    return isApprovedBillingUrl(raw);
  }
  async function claim(code, deviceName) {
    const session = await api.request("/auth/extension/claim", {
      method: "POST",
      body: JSON.stringify({ code: code.trim(), deviceName: deviceName.trim(), extensionVersion: chrome.runtime.getManifest().version })
    }, false);
    await chrome.storage.local.set({ deviceSession: session });
    await heartbeat();
    await injectExistingMetaTabs();
    return { paired: true, deviceId: session.deviceId };
  }
  async function heartbeat() {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);
    try {
      const result = await api.request("/auth/extension/heartbeat", {
        method: "POST",
        body: JSON.stringify({ extensionVersion: chrome.runtime.getManifest().version }),
        signal: controller.signal
      });
      const session = await getSession();
      if (session) await chrome.storage.local.set({ deviceSession: { ...session, expiresAt: result.expiresAt }, lastHeartbeatAt: result.lastSeenAt });
      await drain();
      return result;
    } finally {
      clearTimeout(timeoutId);
    }
  }
  async function pairingStatus(quick = false) {
    const session = await getSession();
    if (!session) return { paired: false, status: "NOT_PAIRED" };
    if (new Date(session.expiresAt).getTime() <= Date.now()) {
      await chrome.storage.local.remove(["deviceSession", "lastHeartbeatAt"]);
      return { paired: false, status: "EXPIRED", error: "Device session expired. Pair this browser again." };
    }
    if (quick) {
      return { paired: true, status: "CONNECTED", online: true, deviceId: session.deviceId, expiresAt: session.expiresAt };
    }
    try {
      const result = await heartbeat();
      return { paired: true, status: "CONNECTED", online: true, deviceId: session.deviceId, expiresAt: result.expiresAt };
    } catch (error) {
      if (error instanceof ApiError && (error.status === 401 || error.status === 403)) {
        await chrome.storage.local.remove(["deviceSession", "lastHeartbeatAt"]);
        return { paired: false, status: "EXPIRED", error: "Device session expired or was revoked. Pair again." };
      }
      return { paired: true, status: "OFFLINE", online: false, deviceId: session.deviceId, expiresAt: session.expiresAt, error: "ADS Control API is temporarily unreachable." };
    }
  }
  async function disconnect() {
    const session = await getSession();
    if (session) await api.request(`/auth/extension/devices/${session.deviceId}`, { method: "DELETE" }).catch(() => void 0);
    await chrome.storage.local.clear();
    return { paired: false, status: "DISCONNECTED" };
  }
  async function context(evidence) {
    const session = await getSession();
    if (!session) return { paired: false };
    try {
      const [accounts, lots, requests] = await Promise.all([
        api.request("/meta-funding/accounts"),
        api.request("/meta-funding/eligibility"),
        api.request("/meta-funding/requests")
      ]);
      const rawMetaId = (evidence == null ? void 0 : evidence.visibleAccountId) || (evidence == null ? void 0 : evidence.urlAccountId);
      const normMetaId = normalizeMetaAccountId(rawMetaId) || "";
      let matches = accounts.filter((a) => {
        const aNorm = normalizeMetaAccountId(a.metaAdAccountId) || "";
        return normMetaId && aNorm === normMetaId || a.metaAdAccountId === rawMetaId;
      });
      if (matches.length === 0 && (evidence == null ? void 0 : evidence.visibleAccountName)) {
        const vName = evidence.visibleAccountName.trim().toLowerCase();
        matches = accounts.filter((a) => a.name.trim().toLowerCase() === vName || a.internalAlias && a.internalAlias.trim().toLowerCase() === vName);
      }
      return {
        paired: true,
        accounts: matches.length > 0 ? matches : accounts,
        lots,
        requests: requests.filter((r) => ["APPROVED", "READY"].includes(r.status)),
        exactAccountId: matches.length > 0 ? matches[0].id : void 0
      };
    } catch (error) {
      if (error instanceof ApiError && (error.status === 401 || error.status === 403)) {
        await chrome.storage.local.remove("deviceSession");
        return { paired: false, error: error.message };
      }
      return { paired: true, error: error instanceof Error ? error.message : "Context fetch failed" };
    }
  }
  async function mapPayment(message) {
    const e = message.evidence;
    if (e.blocked) throw new Error("Account mismatch must be resolved before mapping");
    const idempotencyKey = `map:${e.snapshotHash}:${message.selectedAdAccountId}:${message.sourceId}`;
    const body = {
      idempotencyKey,
      detectedMetaAccountId: e.urlAccountId,
      visibleMetaAccountId: e.visibleAccountId,
      selectedAdAccountId: message.selectedAdAccountId,
      detectedAmountMinor: e.amountMinor,
      selectedAmountMinor: e.amountMinor,
      currencyCode: "INR",
      detectorVersion: e.detectorVersion,
      fundingSourceType: message.sourceType,
      ...message.sourceType === "FUNDING_REQUEST" ? { fundingRequestId: message.sourceId } : { fundLotId: message.sourceId }
    };
    const session = await api.request("/meta-funding/sessions/map", { method: "POST", body: JSON.stringify(body) });
    await chrome.storage.local.set({ [`activeSession:${message.tabId}`]: { id: session.id, evidenceHash: e.snapshotHash } });
    return session;
  }
  async function observe(message, tabId) {
    const key = `activeSession:${tabId}`;
    const active = (await chrome.storage.local.get(key))[key];
    if (!active || !message.evidence.successVisible) return { accepted: true };
    const id = `observe:${active.id}:${message.evidence.snapshotHash}`;
    await queue.enqueue({
      id,
      sessionId: active.id,
      idempotencyKey: id,
      payload: {
        observedAmountMinor: message.evidence.amountMinor,
        visibleMetaAccountId: message.evidence.visibleAccountId,
        detectorVersion: message.evidence.detectorVersion
      }
    });
    await drain();
    return { accepted: true, queued: true };
  }
  async function sendEvent(item) {
    await api.request(`/meta-funding/sessions/${item.sessionId}/observe-success`, {
      method: "POST",
      body: JSON.stringify({ idempotencyKey: item.idempotencyKey, ...item.payload })
    });
  }
  async function drain() {
    return queue.drain(sendEvent);
  }
  async function injectExistingMetaTabs() {
    const tabs = await chrome.tabs.query({
      url: ["https://*.facebook.com/*", "https://*.meta.com/*", "https://facebook.com/*", "https://business.facebook.com/*", "https://adsmanager.facebook.com/*"]
    });
    await Promise.all(tabs.filter((tab) => tab.id !== void 0).map((tab) => ensureContentScript(tab.id, tab.url)));
  }
  async function ensureContentScript(tabId, url) {
    if (!url || !approved(url)) return;
    const alive = await chrome.tabs.sendMessage(tabId, { type: "ADS_CONTROL_PING" }).then(() => true).catch(() => false);
    if (!alive) await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => void 0);
  }
  chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 15 });
    chrome.alarms.create(RETRY_ALARM, { periodInMinutes: 1 });
    void drain();
    void injectExistingMetaTabs();
  });
  chrome.runtime.onStartup.addListener(() => {
    void drain();
    void injectExistingMetaTabs();
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" || changeInfo.url) void ensureContentScript(tabId, tab.url || changeInfo.url);
  });
  chrome.tabs.onActivated.addListener(({ tabId }) => {
    void chrome.tabs.get(tabId).then((tab) => ensureContentScript(tabId, tab.url)).catch(() => void 0);
  });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a.name === HEARTBEAT_ALARM) void pairingStatus();
    if (a.name === RETRY_ALARM) void drain();
  });
  chrome.runtime.onMessage.addListener((m, s, reply) => {
    var _a, _b;
    const tabId = (_a = s.tab) == null ? void 0 : _a.id;
    const senderUrl = s.url || ((_b = s.tab) == null ? void 0 : _b.url) || "";
    const isApproved = approved(senderUrl);
    let op;
    if ((m == null ? void 0 : m.type) === "PAIR") op = claim(m.code, m.deviceName);
    else if ((m == null ? void 0 : m.type) === "HEARTBEAT") op = heartbeat();
    else if ((m == null ? void 0 : m.type) === "GET_CONTEXT") {
      if (!isApproved && !(m == null ? void 0 : m.bypassUrlCheck)) {
        op = Promise.reject(new Error("Unauthorized origin for payment context"));
      } else {
        op = context(m.evidence);
      }
    } else if ((m == null ? void 0 : m.type) === "MAP_TOPUP" && tabId !== void 0) {
      op = mapPayment({ ...m, tabId });
    } else if ((m == null ? void 0 : m.type) === "META_TOPUP_DETECTION" && tabId !== void 0) {
      op = observe(m, tabId);
    } else if ((m == null ? void 0 : m.type) === "PAIRING_STATUS") {
      op = pairingStatus(Boolean(m == null ? void 0 : m.quick));
    } else if ((m == null ? void 0 : m.type) === "DISCONNECT") {
      op = disconnect();
    } else if ((m == null ? void 0 : m.type) === "SET_SETTINGS") {
      op = chrome.storage.local.set(m.settings).then(() => ({ success: true }));
    } else {
      op = Promise.reject(new Error("Unsupported message"));
    }
    op.then(reply).catch((error) => reply({ error: error instanceof Error ? error.message : "Request failed" }));
    return true;
  });
})();
